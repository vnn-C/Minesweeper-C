#include "grid.h"
#include <time.h>
#include <stdlib.h>
#include <stdio.h>

Space** createGrid(int c, int r, int m){
	Space** grid = (Space**)malloc(r * sizeof(Space*));
	int i;
	int j;
    int mCount = 0;
    int rowNum;
    int colNum;
    time_t t;
    srand((unsigned) time(&t));

    
    for(i = 0; i < r; i++){
        grid[i] = (Space*)malloc(c * sizeof(Space));

	        for(j = 0; j < c; j++){
	            grid[i][j].val = 0;
	            grid[i][j].cover = true;
	            grid[i][j].mine = false;
	        }
	    }
    
    bool mPlaced = false;
    while(!mPlaced){
	    for(i = 0; i < r; i++){ //grid x values
	        for(j = 0; j < c; j++){ //grid y values
	            
	            int choice = rand() % 10; //determines if the space will be a mine(0) or not(else)
	            if(choice == 0){
	                
	                grid[i][j].val = 9;
	                grid[i][j].mine = true;
	                mCount++;
	                    
                    //left
	                if(i > 0){
                        rowNum = i - 1;
                        if( !grid[rowNum][j].mine && grid[rowNum][j].val < 9){
                            grid[rowNum][j].val+=1;
                        }
                    //right
                    if(i < r - 1){
                        rowNum = i + 1;
                        if( !grid[rowNum][j].mine && grid[rowNum][j].val < 9){
                            grid[rowNum][j].val+=1;
                        }
                    }
                    //up
                    if(j > 0){
                        colNum = j - 1;
                        if( !grid[i][colNum].mine && grid[i][colNum].val < 9){
                            grid[i][colNum].val+=1;
                        }
                    }
                    //down
                    if(j < c - 1){
                        colNum = j + 1;
                        if( !grid[i][colNum].mine && grid[i][colNum].val < 9){
                            grid[i][colNum].val+=1;
                        }
                    }
                    //upper left
                    if(i > 0 && j > 0){
                        rowNum = i - 1;
                        colNum = j - 1;
                        if( grid[rowNum][colNum].val != 9 && grid[rowNum][colNum].val < 9){
                            grid[rowNum][colNum].val+=1;
                        }
                    }
                    //lower right
                    if(i < r - 1 && j < c - 1){
                        rowNum = i + 1;
                        colNum = j + 1;
                        if( grid[rowNum][colNum].val < 9){
                            grid[rowNum][colNum].val+=1;
                        }
                    }
                    //lower right
                    if(i > 0 && j < c - 1){
                        rowNum = i - 1;
                        colNum = j + 1;
                        if( grid[rowNum][colNum].val < 9){
                            grid[rowNum][colNum].val+=1;
                        }
                    }
                    //upper left
                    if(i < r - 1 && j > 0){
                        rowNum = i + 1;
                        colNum = j - 1;
                        if( grid[rowNum][colNum].val < 9){
                            grid[rowNum][colNum].val+=1;
                        }
                    }
	                    
	                }
	                
	            }
	            
	       }
	       
	       if(mCount == m){
	           mPlaced = true;
	       }
	   }
	 }
	    return grid;

    }
    


void printGrid(Space** grid, int r, int c){
    
    int i;
    int j;
    for(i = 0; i < r; i++){
        for(j = 0; j < c; j++){
            if(grid[i][j].cover == true){
                printf(" X ");
            }
            else{
                printf(" %d ", grid[i][j].val);
            }
        }
        printf("\n");
    }
    
}

int pickSpace(Space** grid, int x, int y){
    
    Space choice = grid[x][y];
    if(grid[x][y].cover == true){
    grid[x][y].cover = false;
    }
    else{
        return 0;
    }
    if(choice.mine){
        return 1;
    }
    else{
        return 2;
    }

}