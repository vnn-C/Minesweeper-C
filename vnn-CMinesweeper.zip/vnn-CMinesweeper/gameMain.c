#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "grid.h"

int main()
{
    int row;
    int col;
    int mines;
    
    

    bool playing = true;
    bool mineHit = false;

    while(playing){
        char input[21];
        char keepPlay[4];
        char keepAns[4];

        printf("Enter the number of rows, columns, and mines (rows,columns,mines)\n");
        fgets(input, 21, stdin);
        sscanf(input, "%d,%d,%d", &row, &col, &mines);

        fflush(stdin);
        printf("%d %d %d\n", row, col, mines);

        Space **grid = (Space**)malloc((row * col) * sizeof(Space*));
printf("Enter\n");
        grid = createGrid(row, col, mines);
printf("Exit\n");
        int mineFree = (row * col) - mines;
        while(mineHit == false){
            
            int result;
            int rowChoice;
            int colChoice;
            char choiceBuf[21];
        
            printGrid(grid, row, col);
        
            printf("Select a square(row#(1-%d),col#(1-%d))\n", row, col);
        
            fgets(choiceBuf, 21, stdin);
           
            sscanf(choiceBuf, "%d,%d", &rowChoice, &colChoice);

            result = pickSpace(grid, rowChoice - 1, colChoice - 1);

            if(result == 0){
                printf("Space is already picked\n");
            }
            else if(result == 1){
                printf("Hit! You lost!\n");
                mineHit = true;
            }
            else{
                printf("Miss\n");
                mineFree-=1;
            }
            if(mineFree == 0){
                printf("You missed all of the mines! You won!\n");
                mineHit = true;
            }
        }
//keep playing the game or not?
        free(grid);

        printf("Do you want to keep playing? Yes or No?\n");
        fgets(keepPlay, 4, stdin);
        sscanf(keepPlay, "%s", keepAns);

        fflush(stdin);
       
        if(strcmp(keepAns, "No") == 0){
            playing = false;
        
        }
        else{
            mineHit = false;
            row = 0;
            col = 0;
            mines = 0;
            //getchar();
            
        }
    }    
    
    return 0;
}
