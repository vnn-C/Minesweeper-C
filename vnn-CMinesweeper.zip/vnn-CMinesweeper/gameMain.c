#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "grid.h"

int main()
{
    int row;
    int col;
    int mines;
    int mineCount = 0;
    Space **grid;
    char input[21];
    
    printf("Enter the number of rows, columns, and mines (rows,columns,mines)\n");
    fgets(input, 21, stdin);
    sscanf(input, "%d,%d,%d", &row, &col, &mines);

    grid = createGrid(row, col, mines);

    //printGrid(grid, row, col);

    
    while(mineCount < mines){
        bool result;
        int rowChoice;
        int colChoice;
        char choiceBuf[21];
        
        printGrid(grid, row, col);
        
        printf("Select a square(row#(1-%d),col#(1-%d))\n", row, col);
        
        fgets(choiceBuf, 21, stdin);
        sscanf(choiceBuf, "%d,%d,", &rowChoice, &colChoice);
        
        result = pickSpace(grid, rowChoice - 1, colChoice - 1);
        
        if(result == true){
            printf("Hit!\n");
            mineCount++;
        }
        else{
            printf("Miss\n");
        }
        if(mineCount == mines){
            printf("You got all of the mines!\n");
        }
    }
    
    
    return 0;
}
