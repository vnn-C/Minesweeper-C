#ifndef GRID_H
#define GRID_H
#include <stdbool.h>

typedef struct{
    
    bool cover; //hides the space's value if true
    int val; //9 if the space is a mine, >9 depending on proximity to the mine
    bool mine; //true if the space is a mine
}Space;

Space** createGrid(int, int, int);
void printGrid(Space**, int, int);
int pickSpace(Space**, int, int);
#endif